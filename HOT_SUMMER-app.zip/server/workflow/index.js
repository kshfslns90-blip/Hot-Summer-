// The one engine the server runs, plus what has to happen when the process starts.
import { Engine } from './engine.js';
import * as instances from './instances.js';
import { callServer } from '../runner.js';
import { runInWorker } from '../jobs/worker-pool.js';

export const engine = new Engine({ callServer, runInWorker });

export { instances };
export { WorkflowError } from './engine.js';

export function startWorkflow(name, args, options) {
  return engine.start(name, args, options);
}

export function signalWorkflow(id, name, payload) {
  return engine.signal(id, name, payload);
}

export function cancelWorkflow(id, reason) {
  return engine.cancel(id, reason);
}

// Picks up where the last run left off. Anything mid-flight resumes from its checkpoint, delays
// that came due while the server was down fire straight away, and debug instances are dropped
// because the watch that justified them is long gone.
export async function boot() {
  await instances.ensureDirs();
  const active = await instances.listActive();
  let resumed = 0;
  let dropped = 0;

  for (const entry of active) {
    if (entry.debug) {
      await engine.cancel(entry.id, 'debug session ended when the server restarted');
      dropped += 1;
      continue;
    }

    // A parent parked on a child that finished while the server was down would otherwise wait
    // forever - the child's completion callback died with the old process. The engine does this
    // under the instance lock from a fresh read, so a tick already started for another instance
    // cannot be overwritten with the snapshot taken above.
    const instance = await engine.reconcileChildren(entry.id);
    if (!instance || instances.FINAL_STATUSES.has(instance.status)) continue;

    // Anything with a token that is not waiting has work to do, whatever the status says.
    const runnable = instance.status === 'running' || (instance.tokens || []).some((t) => !t.wait);
    if (runnable) {
      resumed += 1;
      engine.tick(instance.id).catch((err) => console.error(`[workflow ${instance.id}]`, err));
    }
  }

  await engine.wake();
  const waiting = active.filter((i) => !i.debug && i.status === 'waiting').length;
  if (active.length > 0) {
    console.log(`Workflows: resumed ${resumed}, waiting ${waiting}, dropped ${dropped} debug instance(s)`);
  }
  return { resumed, waiting, dropped };
}
